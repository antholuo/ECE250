#include <iostream>
#include "Resizable_deque.h"

// Every C++ Project in Visual Studio and other IDEs can only have one file with a main() function.
// Thus, if you want this to compile, you must change the name to 'main()' and change the name of
// the 'main()' function in the driver to something else.
int another_main() {
    Resizable_deque<int> deque;

    // write your own test here (OPTIONAL)...

    return 0;
}
